import { useState, useEffect } from 'react';
import { Order, Enquiry, ServiceType, ServiceLocation, ChargeHead, Charge, AppSettings } from '../types';
import { v4 as uuidv4 } from 'uuid';

interface OrderFormProps {
  order?: Order | null;
  enquiry?: Enquiry | null;
  chargeHeads: ChargeHead[];
  settings: AppSettings;
  onSave: (order: Order) => void;
  onCancel: () => void;
  existingOrderCount: number;
}

export function OrderForm({ order, enquiry, chargeHeads, settings, onSave, onCancel, existingOrderCount }: OrderFormProps) {
  const [formData, setFormData] = useState({
    customerName: '',
    phone: '',
    address: '',
    serviceType: 'pre-pleat' as ServiceType,
    serviceLocation: 'at-shop' as ServiceLocation,
    sareeCount: 1,
    sareeReceivedInAdvance: false,
    sareeReceivedDate: '',
    eventDate: '',
    deliveryDate: '',
    baseAmount: settings.prePleatRate,
    notes: ''
  });
  
  const [additionalCharges, setAdditionalCharges] = useState<Charge[]>([]);
  const [newChargeHead, setNewChargeHead] = useState('');
  const [newChargeAmount, setNewChargeAmount] = useState('');

  useEffect(() => {
    if (order) {
      setFormData({
        customerName: order.customerName,
        phone: order.phone,
        address: order.address,
        serviceType: order.serviceType,
        serviceLocation: order.serviceLocation,
        sareeCount: order.sareeCount,
        sareeReceivedInAdvance: order.sareeReceivedInAdvance,
        sareeReceivedDate: order.sareeReceivedDate || '',
        eventDate: order.eventDate,
        deliveryDate: order.deliveryDate,
        baseAmount: order.baseAmount,
        notes: order.notes
      });
      setAdditionalCharges(order.additionalCharges);
    } else if (enquiry) {
      setFormData(prev => ({
        ...prev,
        customerName: enquiry.customerName,
        phone: enquiry.phone,
        serviceType: enquiry.serviceType,
        serviceLocation: enquiry.serviceLocation,
        eventDate: enquiry.eventDate,
        notes: enquiry.notes
      }));
    }
  }, [order, enquiry]);

  useEffect(() => {
    const rate = formData.serviceType === 'pre-pleat' ? settings.prePleatRate :
                 formData.serviceType === 'drape' ? settings.drapeRate :
                 settings.prePleatDrapeRate;
    setFormData(prev => ({ ...prev, baseAmount: rate * prev.sareeCount }));
  }, [formData.serviceType, formData.sareeCount, settings]);

  const totalAmount = formData.baseAmount + additionalCharges.reduce((sum, c) => sum + c.amount, 0);

  const handleAddCharge = () => {
    if (!newChargeHead || !newChargeAmount) return;
    
    const head = chargeHeads.find(h => h.id === newChargeHead);
    if (!head) return;
    
    setAdditionalCharges([...additionalCharges, {
      headId: head.id,
      headName: head.name,
      amount: parseFloat(newChargeAmount)
    }]);
    
    setNewChargeHead('');
    setNewChargeAmount('');
  };

  const handleRemoveCharge = (index: number) => {
    setAdditionalCharges(additionalCharges.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const now = new Date().toISOString();
    const orderNumber = order?.orderNumber || `ED-${String(existingOrderCount + 1).padStart(4, '0')}`;
    
    const newOrder: Order = {
      id: order?.id || uuidv4(),
      orderNumber,
      customerName: formData.customerName,
      phone: formData.phone,
      address: formData.address,
      serviceType: formData.serviceType,
      serviceLocation: formData.serviceLocation,
      sareeCount: formData.sareeCount,
      sareeReceivedDate: formData.sareeReceivedDate || null,
      sareeReceivedInAdvance: formData.sareeReceivedInAdvance,
      eventDate: formData.eventDate,
      deliveryDate: formData.deliveryDate,
      collectedDate: order?.collectedDate || null,
      baseAmount: formData.baseAmount,
      additionalCharges,
      totalAmount,
      amountPaid: order?.amountPaid || 0,
      paymentStatus: order?.paymentStatus || 'pending',
      status: order?.status || 'pending',
      notes: formData.notes,
      enquiryId: enquiry?.id || order?.enquiryId || null,
      createdAt: order?.createdAt || now,
      updatedAt: now
    };
    
    onSave(newOrder);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
      {/* Customer Details */}
      <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-yellow-100">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <div className="p-2 bg-yellow-100 rounded-lg">
            <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </div>
          Customer Details
        </h3>
        
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Customer Name *</label>
            <input
              type="text"
              required
              value={formData.customerName}
              onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
              placeholder="Enter customer name"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone Number *</label>
            <input
              type="tel"
              required
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
              placeholder="Enter phone number"
            />
          </div>
          
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Address</label>
            <textarea
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              rows={2}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
              placeholder="Customer address (required for on-site service)"
            />
          </div>
        </div>
      </div>
      
      {/* Service Details */}
      <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-yellow-100">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <div className="p-2 bg-yellow-100 rounded-lg">
            <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
            </svg>
          </div>
          Service Details
        </h3>
        
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Service Type *</label>
            <select
              value={formData.serviceType}
              onChange={(e) => setFormData({ ...formData, serviceType: e.target.value as ServiceType })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white"
            >
              <option value="pre-pleat">Pre-Pleat Only</option>
              <option value="drape">Drape Only</option>
              <option value="pre-pleat-drape">Pre-Pleat + Drape</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Service Location *</label>
            <select
              value={formData.serviceLocation}
              onChange={(e) => setFormData({ ...formData, serviceLocation: e.target.value as ServiceLocation })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white"
            >
              <option value="at-shop">🏪 At Shop</option>
              <option value="on-site">📍 On-Site (Customer Location)</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Number of Sarees *</label>
            <input
              type="number"
              min="1"
              required
              value={formData.sareeCount}
              onChange={(e) => setFormData({ ...formData, sareeCount: parseInt(e.target.value) || 1 })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Saree Collection</label>
            <div className="flex items-center gap-4 mt-2 flex-wrap">
              <label className="flex items-center gap-2 cursor-pointer bg-gray-50 px-3 py-2 rounded-lg hover:bg-yellow-50 transition-colors">
                <input
                  type="radio"
                  name="sareeCollection"
                  checked={formData.sareeReceivedInAdvance}
                  onChange={() => setFormData({ ...formData, sareeReceivedInAdvance: true })}
                  className="w-4 h-4 text-yellow-600"
                />
                <span className="text-sm">✅ Received</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer bg-gray-50 px-3 py-2 rounded-lg hover:bg-yellow-50 transition-colors">
                <input
                  type="radio"
                  name="sareeCollection"
                  checked={!formData.sareeReceivedInAdvance}
                  onChange={() => setFormData({ ...formData, sareeReceivedInAdvance: false })}
                  className="w-4 h-4 text-yellow-600"
                />
                <span className="text-sm">⏳ Later / On-Site</span>
              </label>
            </div>
          </div>
          
          {formData.sareeReceivedInAdvance && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Saree Received Date</label>
              <input
                type="date"
                value={formData.sareeReceivedDate}
                onChange={(e) => setFormData({ ...formData, sareeReceivedDate: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
              />
            </div>
          )}
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Event Date *</label>
            <input
              type="date"
              required
              value={formData.eventDate}
              onChange={(e) => setFormData({ ...formData, eventDate: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Delivery/Pickup Date</label>
            <input
              type="date"
              value={formData.deliveryDate}
              onChange={(e) => setFormData({ ...formData, deliveryDate: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>
      
      {/* Pricing */}
      <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-yellow-100">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <div className="p-2 bg-yellow-100 rounded-lg">
            <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          Pricing
        </h3>
        
        <div className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Base Amount (₹)</label>
              <input
                type="number"
                min="0"
                value={formData.baseAmount}
                onChange={(e) => setFormData({ ...formData, baseAmount: parseFloat(e.target.value) || 0 })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-lg font-semibold"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Additional Charges</label>
            
            {additionalCharges.length > 0 && (
              <div className="space-y-2 mb-4">
                {additionalCharges.map((charge, index) => (
                  <div key={index} className="flex items-center gap-2 bg-yellow-50 px-3 py-2 rounded-lg border border-yellow-200">
                    <span className="flex-1 text-sm font-medium">{charge.headName}</span>
                    <span className="text-sm font-semibold text-yellow-700">₹{charge.amount}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveCharge(index)}
                      className="text-red-500 hover:text-red-700 p-1"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
            )}
            
            <div className="flex flex-col sm:flex-row gap-2">
              <select
                value={newChargeHead}
                onChange={(e) => {
                  setNewChargeHead(e.target.value);
                  const head = chargeHeads.find(h => h.id === e.target.value);
                  if (head) setNewChargeAmount(head.defaultAmount.toString());
                }}
                className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white"
              >
                <option value="">Select charge type...</option>
                {chargeHeads.map(head => (
                  <option key={head.id} value={head.id}>{head.name} (₹{head.defaultAmount})</option>
                ))}
              </select>
              
              <input
                type="number"
                placeholder="₹ Amount"
                value={newChargeAmount}
                onChange={(e) => setNewChargeAmount(e.target.value)}
                className="w-full sm:w-28 px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
              />
              
              <button
                type="button"
                onClick={handleAddCharge}
                className="px-6 py-2.5 bg-black text-yellow-400 rounded-xl hover:bg-gray-900 font-medium btn-press whitespace-nowrap"
              >
                + Add
              </button>
            </div>
          </div>
          
          <div className="pt-4 border-t border-gray-200">
            <div className="flex justify-between items-center bg-gradient-to-r from-yellow-400 to-amber-500 text-black p-4 rounded-xl shadow-lg">
              <span className="text-lg font-medium">Total Amount</span>
              <span className="text-2xl font-bold">₹{totalAmount}</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Notes */}
      <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-yellow-100">
        <label className="block text-sm font-medium text-gray-700 mb-1.5">Notes / Special Instructions</label>
        <textarea
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          rows={3}
          placeholder="Any special instructions, preferences, or notes..."
          className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
        />
      </div>
      
      {/* Actions */}
      <div className="flex gap-3 sm:gap-4">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-6 py-3.5 bg-gray-100 text-gray-600 rounded-xl font-medium hover:bg-gray-200 transition-colors btn-press"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="flex-1 px-6 py-3.5 bg-gradient-to-r from-yellow-400 to-amber-500 text-black rounded-xl font-bold hover:from-yellow-500 hover:to-amber-600 transition-all shadow-lg btn-press"
        >
          {order ? 'Update Order' : 'Create Order'}
        </button>
      </div>
    </form>
  );
}
