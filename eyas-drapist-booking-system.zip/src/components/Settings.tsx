import { useState } from 'react';
import { ChargeHead, AppData, AppSettings } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { backupData, exportToPDF, exportToExcel, exportToCSV, generateGoogleSheetsCSV, exportEnquiriesToExcel } from '../utils/exportUtils';

interface SettingsProps {
  settings: AppSettings;
  chargeHeads: ChargeHead[];
  appData: AppData;
  onUpdateSettings: (settings: AppSettings) => void;
  onUpdateChargeHeads: (heads: ChargeHead[]) => void;
  onRestoreData: (data: AppData) => void;
}

export function Settings({ settings, chargeHeads, appData, onUpdateSettings, onUpdateChargeHeads, onRestoreData }: SettingsProps) {
  const [localSettings, setLocalSettings] = useState(settings);
  const [newHeadName, setNewHeadName] = useState('');
  const [newHeadAmount, setNewHeadAmount] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSaveSettings = () => {
    onUpdateSettings(localSettings);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2000);
  };

  const handleAddChargeHead = () => {
    if (!newHeadName) return;
    
    const newHead: ChargeHead = {
      id: uuidv4(),
      name: newHeadName,
      defaultAmount: parseFloat(newHeadAmount) || 0,
      isSystem: false
    };
    
    onUpdateChargeHeads([...chargeHeads, newHead]);
    setNewHeadName('');
    setNewHeadAmount('');
  };

  const handleDeleteChargeHead = (id: string) => {
    const head = chargeHeads.find(h => h.id === id);
    if (head?.isSystem) {
      alert('Cannot delete system charge heads');
      return;
    }
    onUpdateChargeHeads(chargeHeads.filter(h => h.id !== id));
  };

  const handleBackup = () => {
    backupData(appData);
  };

  const handleRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string) as AppData;
        if (data.enquiries && data.orders && data.settings) {
          onRestoreData(data);
          alert('Data restored successfully! 🎉');
        } else {
          alert('Invalid backup file format');
        }
      } catch {
        alert('Failed to parse backup file');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <h1 className="text-xl sm:text-2xl font-bold text-gray-900">⚙️ Settings</h1>
      
      {/* Success Toast */}
      {showSuccess && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-green-500 text-white px-6 py-3 rounded-xl shadow-lg z-50 animate-pulse">
          ✅ Settings saved successfully!
        </div>
      )}
      
      {/* Business Settings */}
      <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-yellow-100">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <div className="p-2 bg-yellow-100 rounded-lg">
            <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
          </div>
          Business Information
        </h3>
        
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Business Name</label>
            <input
              type="text"
              value={localSettings.businessName}
              onChange={(e) => setLocalSettings({ ...localSettings, businessName: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone</label>
            <input
              type="tel"
              value={localSettings.phone}
              onChange={(e) => setLocalSettings({ ...localSettings, phone: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
              placeholder="Your business phone"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Instagram Handle</label>
            <div className="flex">
              <span className="inline-flex items-center px-3 bg-gray-100 border border-r-0 border-gray-200 rounded-l-xl text-gray-500 text-sm">@</span>
              <input
                type="text"
                value={localSettings.instagram}
                onChange={(e) => setLocalSettings({ ...localSettings, instagram: e.target.value })}
                className="flex-1 px-4 py-2.5 border border-gray-200 rounded-r-xl focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
                placeholder="your_instagram_handle"
              />
            </div>
          </div>
          
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Address</label>
            <textarea
              value={localSettings.address}
              onChange={(e) => setLocalSettings({ ...localSettings, address: e.target.value })}
              rows={2}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500"
              placeholder="Your business address"
            />
          </div>
        </div>
      </div>
      
      {/* Pricing */}
      <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-yellow-100">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <div className="p-2 bg-yellow-100 rounded-lg">
            <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          Default Pricing (Per Saree)
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
            <label className="block text-sm font-medium text-gray-800 mb-1.5">Pre-Pleat Rate (₹)</label>
            <input
              type="number"
              value={localSettings.prePleatRate}
              onChange={(e) => setLocalSettings({ ...localSettings, prePleatRate: parseFloat(e.target.value) || 0 })}
              className="w-full px-4 py-2.5 border border-yellow-300 rounded-xl focus:ring-2 focus:ring-yellow-500 text-lg font-semibold bg-white"
            />
          </div>
          
          <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
            <label className="block text-sm font-medium text-gray-800 mb-1.5">Drape Rate (₹)</label>
            <input
              type="number"
              value={localSettings.drapeRate}
              onChange={(e) => setLocalSettings({ ...localSettings, drapeRate: parseFloat(e.target.value) || 0 })}
              className="w-full px-4 py-2.5 border border-yellow-300 rounded-xl focus:ring-2 focus:ring-yellow-500 text-lg font-semibold bg-white"
            />
          </div>
          
          <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
            <label className="block text-sm font-medium text-gray-800 mb-1.5">Pre-Pleat + Drape (₹)</label>
            <input
              type="number"
              value={localSettings.prePleatDrapeRate}
              onChange={(e) => setLocalSettings({ ...localSettings, prePleatDrapeRate: parseFloat(e.target.value) || 0 })}
              className="w-full px-4 py-2.5 border border-yellow-300 rounded-xl focus:ring-2 focus:ring-yellow-500 text-lg font-semibold bg-white"
            />
          </div>
        </div>
        
        <button
          onClick={handleSaveSettings}
          className="mt-4 w-full sm:w-auto px-8 py-3 bg-gradient-to-r from-yellow-400 to-amber-500 text-black rounded-xl font-bold hover:from-yellow-500 hover:to-amber-600 transition-all shadow-lg btn-press"
        >
          💾 Save Settings
        </button>
      </div>
      
      {/* Charge Heads */}
      <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-yellow-100">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <div className="p-2 bg-yellow-100 rounded-lg">
            <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
          </div>
          Additional Charge Heads
        </h3>
        
        <div className="space-y-2 mb-4">
          {chargeHeads.map(head => (
            <div key={head.id} className="flex items-center justify-between bg-gray-50 px-4 py-3 rounded-xl">
              <div className="flex items-center gap-2">
                <span className="font-medium">{head.name}</span>
                <span className="text-yellow-600 font-semibold">₹{head.defaultAmount}</span>
                {head.isSystem && (
                  <span className="px-2 py-0.5 text-xs bg-gray-200 text-gray-600 rounded font-medium">System</span>
                )}
              </div>
              {!head.isSystem && (
                <button
                  onClick={() => handleDeleteChargeHead(head.id)}
                  className="text-red-500 hover:text-red-700 p-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              )}
            </div>
          ))}
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            placeholder="Charge Name (e.g., Makeup)"
            value={newHeadName}
            onChange={(e) => setNewHeadName(e.target.value)}
            className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500"
          />
          <input
            type="number"
            placeholder="Default ₹"
            value={newHeadAmount}
            onChange={(e) => setNewHeadAmount(e.target.value)}
            className="w-full sm:w-28 px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500"
          />
          <button
            onClick={handleAddChargeHead}
            className="px-6 py-2.5 bg-black text-yellow-400 rounded-xl font-bold hover:bg-gray-900 btn-press whitespace-nowrap"
          >
            + Add
          </button>
        </div>
      </div>
      
      {/* Export Options */}
      <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-yellow-100">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <div className="p-2 bg-yellow-100 rounded-lg">
            <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
          </div>
          Export Data
        </h3>
        
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => exportToPDF(appData.orders, 'All Orders')}
            className="flex flex-col items-center gap-2 px-4 py-4 bg-red-50 text-red-700 rounded-xl hover:bg-red-100 transition-colors btn-press border border-red-100"
          >
            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 2l5 5h-5V4zM8 17h8v2H8v-2zm0-4h8v2H8v-2zm0-4h5v2H8V9z"/>
            </svg>
            <span className="text-sm font-medium">PDF</span>
          </button>
          
          <button
            onClick={() => exportToExcel(appData.orders, 'orders')}
            className="flex flex-col items-center gap-2 px-4 py-4 bg-green-50 text-green-700 rounded-xl hover:bg-green-100 transition-colors btn-press border border-green-100"
          >
            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM9.5 17.5l-2-3 2-3h1.5l-2 3 2 3H9.5zm5.5 0h-1.5l-2-3 2-3H15l-2 3 2 3z"/>
            </svg>
            <span className="text-sm font-medium">Excel</span>
          </button>
          
          <button
            onClick={() => exportToCSV(appData.orders, 'orders')}
            className="flex flex-col items-center gap-2 px-4 py-4 bg-blue-50 text-blue-700 rounded-xl hover:bg-blue-100 transition-colors btn-press border border-blue-100"
          >
            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 2l5 5h-5V4zM6 20V4h5v6h6v10H6z"/>
            </svg>
            <span className="text-sm font-medium">CSV</span>
          </button>
          
          <button
            onClick={() => generateGoogleSheetsCSV(appData.orders)}
            className="flex flex-col items-center gap-2 px-4 py-4 bg-yellow-50 text-yellow-700 rounded-xl hover:bg-yellow-100 transition-colors btn-press border border-yellow-200"
          >
            <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
              <path d="M19.5 3H4.5C3.12 3 2 4.12 2 5.5v13C2 19.88 3.12 21 4.5 21h15c1.38 0 2.5-1.12 2.5-2.5v-13C22 4.12 20.88 3 19.5 3zM4.5 5h15c.28 0 .5.22.5.5V8H4V5.5c0-.28.22-.5.5-.5zM4 10h16v4H4v-4zm.5 9c-.28 0-.5-.22-.5-.5V16h16v2.5c0 .28-.22.5-.5.5h-15z"/>
            </svg>
            <span className="text-sm font-medium">Sheets</span>
          </button>
        </div>
        
        <div className="mt-4">
          <button
            onClick={() => exportEnquiriesToExcel(appData.enquiries)}
            className="flex items-center gap-2 px-4 py-2.5 bg-purple-50 text-purple-700 rounded-xl hover:bg-purple-100 transition-colors btn-press border border-purple-100"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Export Enquiries
          </button>
        </div>
      </div>
      
      {/* Backup & Restore */}
      <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-yellow-100">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <div className="p-2 bg-yellow-100 rounded-lg">
            <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
            </svg>
          </div>
          Backup & Restore
        </h3>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleBackup}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-yellow-400 to-amber-500 text-black rounded-xl font-bold hover:from-yellow-500 hover:to-amber-600 transition-all shadow-lg btn-press"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Backup All Data
          </button>
          
          <label className="flex items-center justify-center gap-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors cursor-pointer btn-press">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            Restore from Backup
            <input
              type="file"
              accept=".json"
              onChange={handleRestore}
              className="hidden"
            />
          </label>
        </div>
        
        <div className="mt-4 p-4 bg-yellow-50 rounded-xl border border-yellow-200">
          <p className="text-sm text-gray-700 flex items-start gap-2">
            <span className="text-lg">💡</span>
            <span><strong>Tip:</strong> Regularly backup your data to prevent data loss. You can import the backup file to restore all your enquiries, orders, and settings.</span>
          </p>
        </div>
      </div>
      
      {/* App Info */}
      <div className="bg-gradient-to-r from-gray-900 via-black to-gray-900 rounded-xl sm:rounded-2xl p-6 text-white text-center border border-yellow-500/20">
        <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 flex items-center justify-center shadow-lg">
          <span className="text-black font-bold text-2xl">E</span>
        </div>
        <h3 className="text-xl font-bold text-yellow-400">Eyas Saree Drapist</h3>
        <p className="text-gray-400 text-sm mt-1">Pre-Pleat & Drape Services</p>
        <a 
          href="https://www.instagram.com/eyas_sareedrapist_namakkal/" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 mt-3 text-gray-300 hover:text-yellow-400 transition-colors"
        >
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069z"/>
          </svg>
          @eyas_sareedrapist_namakkal
        </a>
        <p className="text-gray-500 text-xs mt-4">Made with ❤️ for your business</p>
      </div>
    </div>
  );
}
