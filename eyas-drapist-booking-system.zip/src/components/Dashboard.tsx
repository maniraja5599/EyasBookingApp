import { Order, Enquiry, AppSettings } from '../types';
import { isToday, isTomorrow, format } from 'date-fns';

interface DashboardProps {
  orders: Order[];
  enquiries: Enquiry[];
  settings: AppSettings;
}

export function Dashboard({ orders, enquiries, settings }: DashboardProps) {
  const pendingOrders = orders.filter(o => o.status !== 'delivered' && o.status !== 'completed');
  const pendingPayments = orders.filter(o => o.paymentStatus !== 'paid');
  const newEnquiries = enquiries.filter(e => e.status === 'new' || e.status === 'follow-up');
  
  const totalRevenue = orders.reduce((sum, o) => sum + o.amountPaid, 0);
  const pendingAmount = orders.reduce((sum, o) => sum + (o.totalAmount - o.amountPaid), 0);
  
  const todayDeliveries = orders.filter(o => 
    o.eventDate && isToday(new Date(o.eventDate)) && o.status !== 'delivered'
  );
  
  const tomorrowDeliveries = orders.filter(o => 
    o.eventDate && isTomorrow(new Date(o.eventDate)) && o.status !== 'delivered'
  );

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-gray-900 via-black to-gray-900 rounded-2xl sm:rounded-3xl p-5 sm:p-8 text-white shadow-xl relative overflow-hidden border border-yellow-500/20">
        <div className="absolute top-0 right-0 w-40 h-40 bg-yellow-400/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-yellow-400/10 rounded-full translate-y-1/2 -translate-x-1/2"></div>
        
        <div className="relative">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 flex items-center justify-center shadow-lg">
              <span className="text-black font-bold text-lg sm:text-xl">E</span>
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-yellow-400">{settings.businessName}</h1>
              <p className="text-gray-300 text-sm">Vanakkam! Welcome back! 🙏</p>
            </div>
          </div>
          <a 
            href="https://www.instagram.com/eyas_sareedrapist_namakkal/" 
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 text-sm mt-4 flex items-center gap-2 hover:text-yellow-400 transition-colors"
          >
            <svg className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069z"/>
            </svg>
            @eyas_sareedrapist_namakkal
          </a>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-5 shadow-sm border border-yellow-100 card-hover">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-3 bg-gradient-to-br from-yellow-100 to-yellow-50 rounded-xl">
              <svg className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
            </div>
            <div>
              <p className="text-xs sm:text-sm text-gray-500">Pending</p>
              <p className="text-xl sm:text-2xl font-bold text-gray-900">{pendingOrders.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-5 shadow-sm border border-yellow-100 card-hover">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-3 bg-gradient-to-br from-amber-100 to-amber-50 rounded-xl">
              <svg className="w-5 h-5 sm:w-6 sm:h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <p className="text-xs sm:text-sm text-gray-500">Enquiries</p>
              <p className="text-xl sm:text-2xl font-bold text-gray-900">{newEnquiries.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-5 shadow-sm border border-yellow-100 card-hover">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-3 bg-gradient-to-br from-green-100 to-green-50 rounded-xl">
              <svg className="w-5 h-5 sm:w-6 sm:h-6 text-green-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <p className="text-xs sm:text-sm text-gray-500">Received</p>
              <p className="text-lg sm:text-2xl font-bold text-gray-900">₹{totalRevenue.toLocaleString()}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-5 shadow-sm border border-yellow-100 card-hover">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-3 bg-gradient-to-br from-red-100 to-red-50 rounded-xl">
              <svg className="w-5 h-5 sm:w-6 sm:h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <p className="text-xs sm:text-sm text-gray-500">Pending</p>
              <p className="text-lg sm:text-2xl font-bold text-gray-900">₹{pendingAmount.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Upcoming Events */}
      <div className="grid lg:grid-cols-2 gap-4 sm:gap-6">
        <div className="bg-white rounded-xl sm:rounded-2xl shadow-sm border border-yellow-100 overflow-hidden card-hover">
          <div className="p-4 bg-gradient-to-r from-gray-900 to-black">
            <h2 className="font-semibold text-yellow-400 flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Today's Events ({todayDeliveries.length})
            </h2>
          </div>
          <div className="divide-y divide-gray-100 max-h-64 overflow-y-auto">
            {todayDeliveries.length === 0 ? (
              <div className="p-6 text-center">
                <div className="w-16 h-16 mx-auto mb-3 bg-yellow-50 rounded-full flex items-center justify-center">
                  <svg className="w-8 h-8 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
                <p className="text-gray-500 text-sm">No events today</p>
              </div>
            ) : (
              todayDeliveries.map(order => (
                <div key={order.id} className="p-4 hover:bg-yellow-50/50 transition-colors">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-gray-900">{order.customerName}</p>
                      <p className="text-sm text-gray-500">{order.orderNumber} • {order.serviceType.replace('-', ' ')}</p>
                      <p className="text-xs text-gray-400 mt-1">👗 {order.sareeCount} saree{order.sareeCount > 1 ? 's' : ''}</p>
                    </div>
                    <span className={`px-2.5 py-1 text-xs font-medium rounded-full ${
                      order.status === 'completed' ? 'bg-green-100 text-green-700' :
                      order.status === 'in-progress' ? 'bg-blue-100 text-blue-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {order.status.replace('-', ' ')}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
        
        <div className="bg-white rounded-xl sm:rounded-2xl shadow-sm border border-yellow-100 overflow-hidden card-hover">
          <div className="p-4 bg-gradient-to-r from-amber-500 to-yellow-500">
            <h2 className="font-semibold text-black flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              Tomorrow's Events ({tomorrowDeliveries.length})
            </h2>
          </div>
          <div className="divide-y divide-gray-100 max-h-64 overflow-y-auto">
            {tomorrowDeliveries.length === 0 ? (
              <div className="p-6 text-center">
                <div className="w-16 h-16 mx-auto mb-3 bg-gray-100 rounded-full flex items-center justify-center">
                  <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
                <p className="text-gray-500 text-sm">No events tomorrow</p>
              </div>
            ) : (
              tomorrowDeliveries.map(order => (
                <div key={order.id} className="p-4 hover:bg-yellow-50/50 transition-colors">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-gray-900">{order.customerName}</p>
                      <p className="text-sm text-gray-500">{order.orderNumber} • {order.serviceType.replace('-', ' ')}</p>
                      <p className="text-xs text-gray-400 mt-1">👗 {order.sareeCount} saree{order.sareeCount > 1 ? 's' : ''}</p>
                    </div>
                    <span className={`px-2.5 py-1 text-xs font-medium rounded-full ${
                      order.status === 'completed' ? 'bg-green-100 text-green-700' :
                      order.status === 'in-progress' ? 'bg-blue-100 text-blue-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {order.status.replace('-', ' ')}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
      
      {/* Pending Payments */}
      <div className="bg-white rounded-xl sm:rounded-2xl shadow-sm border border-yellow-100 overflow-hidden">
        <div className="p-4 bg-gradient-to-r from-green-600 to-emerald-600">
          <h2 className="font-semibold text-white flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
            Pending Payments ({pendingPayments.length})
          </h2>
        </div>
        <div className="overflow-x-auto">
          {pendingPayments.length === 0 ? (
            <div className="p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-3 bg-green-100 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <p className="text-gray-500">All payments collected! 🎉</p>
            </div>
          ) : (
            <table className="w-full">
              <thead className="bg-gray-900">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-yellow-400 uppercase">Customer</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-yellow-400 uppercase hidden sm:table-cell">Order</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-yellow-400 uppercase">Total</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-yellow-400 uppercase hidden sm:table-cell">Paid</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-yellow-400 uppercase">Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {pendingPayments.slice(0, 5).map(order => (
                  <tr key={order.id} className="hover:bg-yellow-50/50 transition-colors">
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium text-gray-900">{order.customerName}</p>
                      <p className="text-xs text-gray-500 sm:hidden">{order.orderNumber}</p>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-500 hidden sm:table-cell">{order.orderNumber}</td>
                    <td className="px-4 py-3 text-sm text-gray-900">₹{order.totalAmount}</td>
                    <td className="px-4 py-3 text-sm text-green-600 hidden sm:table-cell">₹{order.amountPaid}</td>
                    <td className="px-4 py-3 text-sm font-semibold text-red-600">₹{order.totalAmount - order.amountPaid}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Recent Orders */}
      {orders.length > 0 && (
        <div className="bg-white rounded-xl sm:rounded-2xl shadow-sm border border-yellow-100 overflow-hidden">
          <div className="p-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-900 flex items-center gap-2">
              <svg className="w-5 h-5 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Recent Orders
            </h2>
          </div>
          <div className="divide-y divide-gray-100">
            {orders.slice(0, 3).map(order => (
              <div key={order.id} className="p-4 hover:bg-yellow-50/50 transition-colors">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <p className="font-medium text-gray-900">{order.customerName}</p>
                    <p className="text-sm text-gray-500">
                      {order.orderNumber} • {order.serviceType.replace('-', ' ')} • 
                      {order.eventDate && ` ${format(new Date(order.eventDate), 'dd MMM')}`}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-yellow-600">₹{order.totalAmount}</span>
                    <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                      order.status === 'delivered' ? 'bg-gray-100 text-gray-600' :
                      order.status === 'completed' ? 'bg-green-100 text-green-700' :
                      order.status === 'in-progress' ? 'bg-blue-100 text-blue-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {order.status.replace('-', ' ')}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
