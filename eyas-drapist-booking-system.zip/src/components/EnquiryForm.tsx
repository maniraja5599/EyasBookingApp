import { useState } from 'react';
import { Enquiry, ServiceType, ServiceLocation } from '../types';
import { v4 as uuidv4 } from 'uuid';

interface EnquiryFormProps {
  onSave: (enquiry: Enquiry) => void;
  onCancel: () => void;
}

export function EnquiryForm({ onSave, onCancel }: EnquiryFormProps) {
  const [formData, setFormData] = useState({
    customerName: '',
    phone: '',
    serviceType: 'pre-pleat' as ServiceType,
    serviceLocation: 'at-shop' as ServiceLocation,
    eventDate: '',
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const now = new Date().toISOString();
    
    const enquiry: Enquiry = {
      id: uuidv4(),
      customerName: formData.customerName,
      phone: formData.phone,
      serviceType: formData.serviceType,
      serviceLocation: formData.serviceLocation,
      eventDate: formData.eventDate,
      notes: formData.notes,
      status: 'new',
      createdAt: now,
      updatedAt: now
    };
    
    onSave(enquiry);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
      <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-sm border border-yellow-100">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <div className="p-2 bg-yellow-100 rounded-lg">
            <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          Enquiry Details
        </h3>
        
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Customer Name *</label>
            <input
              type="text"
              required
              value={formData.customerName}
              onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
              placeholder="Enter customer name"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone Number *</label>
            <input
              type="tel"
              required
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
              placeholder="Enter phone number"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Service Type *</label>
            <select
              value={formData.serviceType}
              onChange={(e) => setFormData({ ...formData, serviceType: e.target.value as ServiceType })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white"
            >
              <option value="pre-pleat">Pre-Pleat Only</option>
              <option value="drape">Drape Only</option>
              <option value="pre-pleat-drape">Pre-Pleat + Drape</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Service Location *</label>
            <select
              value={formData.serviceLocation}
              onChange={(e) => setFormData({ ...formData, serviceLocation: e.target.value as ServiceLocation })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent bg-white"
            >
              <option value="at-shop">🏪 At Shop</option>
              <option value="on-site">📍 On-Site (Customer Location)</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Event Date</label>
            <input
              type="date"
              value={formData.eventDate}
              onChange={(e) => setFormData({ ...formData, eventDate: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            />
          </div>
          
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Notes</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
              placeholder="Any additional details about the enquiry..."
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>
      
      <div className="flex gap-3 sm:gap-4">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-6 py-3.5 bg-gray-100 text-gray-600 rounded-xl font-medium hover:bg-gray-200 transition-colors btn-press"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="flex-1 px-6 py-3.5 bg-gradient-to-r from-yellow-400 to-amber-500 text-black rounded-xl font-bold hover:from-yellow-500 hover:to-amber-600 transition-all shadow-lg btn-press"
        >
          Save Enquiry
        </button>
      </div>
    </form>
  );
}
