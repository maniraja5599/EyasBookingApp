import React, { useState, useEffect } from 'react';

// Types
interface Enquiry {
  id: string;
  customerName: string;
  phone: string;
  serviceType: 'pre-pleat' | 'drape' | 'both';
  location: 'shop' | 'onsite';
  eventDate: string;
  sareeCount: number;
  notes: string;
  status: 'new' | 'follow-up' | 'converted' | 'cancelled';
  createdAt: string;
}

interface AdditionalCharge {
  name: string;
  amount: number;
}

interface Payment {
  id: string;
  amount: number;
  date: string;
  mode: string;
}

interface Order {
  id: string;
  customerName: string;
  phone: string;
  address: string;
  serviceType: 'pre-pleat' | 'drape' | 'both';
  location: 'shop' | 'onsite';
  sareeCount: number;
  sareeReceivedInAdvance: boolean;
  sareeReceivedDate: string;
  eventDate: string;
  deliveryDate: string;
  collectionDate: string;
  baseAmount: number;
  additionalCharges: AdditionalCharge[];
  totalAmount: number;
  payments: Payment[];
  amountPaid: number;
  status: 'pending' | 'received' | 'in-progress' | 'completed' | 'delivered';
  notes: string;
  createdAt: string;
}

interface Settings {
  businessName: string;
  phone: string;
  address: string;
  instagram: string;
  prePleatRate: number;
  drapeRate: number;
  bothRate: number;
  customChargeHeads: string[];
}

// Helper functions
const generateId = () => Math.random().toString(36).substr(2, 9);

const formatDate = (date: string) => {
  if (!date) return '-';
  return new Date(date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
};

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 0 }).format(amount);
};

// Main App Component
const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'orders' | 'enquiries' | 'settings'>('dashboard');
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [showEnquiryForm, setShowEnquiryForm] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [editingEnquiry, setEditingEnquiry] = useState<Enquiry | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('eyas_orders');
    return saved ? JSON.parse(saved) : [];
  });

  const [enquiries, setEnquiries] = useState<Enquiry[]>(() => {
    const saved = localStorage.getItem('eyas_enquiries');
    return saved ? JSON.parse(saved) : [];
  });

  const [settings, setSettings] = useState<Settings>(() => {
    const saved = localStorage.getItem('eyas_settings');
    return saved ? JSON.parse(saved) : {
      businessName: 'Eyas Saree Drapist',
      phone: '',
      address: 'Namakkal',
      instagram: '@eyas_sareedrapist_namakkal',
      prePleatRate: 150,
      drapeRate: 500,
      bothRate: 600,
      customChargeHeads: ['Travel', 'Urgent', 'Extra Pleats']
    };
  });

  useEffect(() => {
    localStorage.setItem('eyas_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('eyas_enquiries', JSON.stringify(enquiries));
  }, [enquiries]);

  useEffect(() => {
    localStorage.setItem('eyas_settings', JSON.stringify(settings));
  }, [settings]);

  const handleSaveOrder = (order: Order) => {
    if (editingOrder) {
      setOrders(orders.map(o => o.id === order.id ? order : o));
    } else {
      setOrders([...orders, { ...order, id: generateId(), createdAt: new Date().toISOString() }]);
    }
    setShowOrderForm(false);
    setEditingOrder(null);
  };

  const handleSaveEnquiry = (enquiry: Enquiry) => {
    if (editingEnquiry) {
      setEnquiries(enquiries.map(e => e.id === enquiry.id ? enquiry : e));
    } else {
      setEnquiries([...enquiries, { ...enquiry, id: generateId(), createdAt: new Date().toISOString() }]);
    }
    setShowEnquiryForm(false);
    setEditingEnquiry(null);
  };

  const convertEnquiryToOrder = (enquiry: Enquiry) => {
    const rate = enquiry.serviceType === 'pre-pleat' ? settings.prePleatRate : 
                 enquiry.serviceType === 'drape' ? settings.drapeRate : settings.bothRate;
    const baseAmount = rate * enquiry.sareeCount;
    
    const newOrder: Order = {
      id: generateId(),
      customerName: enquiry.customerName,
      phone: enquiry.phone,
      address: '',
      serviceType: enquiry.serviceType,
      location: enquiry.location,
      sareeCount: enquiry.sareeCount,
      sareeReceivedInAdvance: false,
      sareeReceivedDate: '',
      eventDate: enquiry.eventDate,
      deliveryDate: '',
      collectionDate: '',
      baseAmount: baseAmount,
      additionalCharges: [],
      totalAmount: baseAmount,
      payments: [],
      amountPaid: 0,
      status: 'pending',
      notes: enquiry.notes,
      createdAt: new Date().toISOString()
    };

    setOrders([...orders, newOrder]);
    setEnquiries(enquiries.map(e => e.id === enquiry.id ? { ...e, status: 'converted' as const } : e));
  };

  // Common button style
  const btnPrimary: React.CSSProperties = {
    background: 'linear-gradient(135deg, #FFD700, #FFA500)',
    color: '#000',
    fontWeight: 'bold',
    padding: '12px 24px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    fontSize: '14px',
    transition: 'all 0.3s ease',
  };

  const btnSecondary: React.CSSProperties = {
    background: 'transparent',
    color: '#FFD700',
    fontWeight: 'bold',
    padding: '12px 24px',
    borderRadius: '8px',
    border: '2px solid #FFD700',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    fontSize: '14px',
  };

  const cardStyle: React.CSSProperties = {
    background: '#1a1a1a',
    borderRadius: '12px',
    padding: '20px',
    border: '1px solid #333',
  };

  // Navigation items
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'orders', label: 'Orders', icon: '📦' },
    { id: 'enquiries', label: 'Enquiries', icon: '📋' },
    { id: 'settings', label: 'Settings', icon: '⚙️' },
  ];

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: '#000', 
      color: '#fff',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {/* Header */}
      <header style={{
        background: 'linear-gradient(135deg, #1a1a1a, #000)',
        padding: '16px 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottom: '2px solid #FFD700',
        position: 'sticky',
        top: 0,
        zIndex: 100,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            style={{
              background: 'none',
              border: 'none',
              color: '#FFD700',
              fontSize: '24px',
              cursor: 'pointer',
              display: 'block',
            }}
          >
            ☰
          </button>
          <div style={{
            width: '45px',
            height: '45px',
            background: 'linear-gradient(135deg, #FFD700, #FFA500)',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontWeight: 'bold',
            fontSize: '24px',
            color: '#000',
          }}>
            E
          </div>
          <div>
            <h1 style={{ 
              fontSize: '18px', 
              fontWeight: 'bold',
              background: 'linear-gradient(135deg, #FFD700, #FFA500)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              margin: 0,
            }}>
              Eyas Saree Drapist
            </h1>
            <p style={{ fontSize: '11px', color: '#888', margin: 0 }}>Namakkal</p>
          </div>
        </div>
        <a 
          href="https://www.instagram.com/eyas_sareedrapist_namakkal/" 
          target="_blank" 
          rel="noopener noreferrer"
          style={{ color: '#FFD700', fontSize: '24px', textDecoration: 'none' }}
        >
          📸
        </a>
      </header>

      <div style={{ display: 'flex', flex: 1 }}>
        {/* Sidebar */}
        <aside style={{
          width: sidebarOpen ? '250px' : '0',
          background: '#111',
          borderRight: sidebarOpen ? '1px solid #333' : 'none',
          overflow: 'hidden',
          transition: 'width 0.3s ease',
          position: 'fixed',
          top: '77px',
          left: 0,
          bottom: '70px',
          zIndex: 90,
        }}>
          <nav style={{ padding: '20px' }}>
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => { setActiveTab(item.id as any); setSidebarOpen(false); }}
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  background: activeTab === item.id ? 'linear-gradient(135deg, #FFD700, #FFA500)' : 'transparent',
                  color: activeTab === item.id ? '#000' : '#fff',
                  border: 'none',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  fontSize: '15px',
                  fontWeight: activeTab === item.id ? 'bold' : 'normal',
                  marginBottom: '8px',
                  textAlign: 'left',
                }}
              >
                <span style={{ fontSize: '20px' }}>{item.icon}</span>
                {item.label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Overlay */}
        {sidebarOpen && (
          <div 
            onClick={() => setSidebarOpen(false)}
            style={{
              position: 'fixed',
              top: '77px',
              left: '250px',
              right: 0,
              bottom: 0,
              background: 'rgba(0,0,0,0.5)',
              zIndex: 80,
            }}
          />
        )}

        {/* Main Content */}
        <main style={{ 
          flex: 1, 
          padding: '20px',
          paddingBottom: '90px',
          overflowY: 'auto',
        }}>
          {activeTab === 'dashboard' && (
            <Dashboard 
              orders={orders} 
              enquiries={enquiries}
              cardStyle={cardStyle}
              onViewOrders={() => setActiveTab('orders')}
              onViewEnquiries={() => setActiveTab('enquiries')}
            />
          )}
          
          {activeTab === 'orders' && (
            <OrderList 
              orders={orders}
              settings={settings}
              cardStyle={cardStyle}
              btnPrimary={btnPrimary}
              onEdit={(order) => { setEditingOrder(order); setShowOrderForm(true); }}
              onDelete={(id) => setOrders(orders.filter(o => o.id !== id))}
              onUpdateStatus={(id, status) => setOrders(orders.map(o => o.id === id ? {...o, status} : o))}
              onAddPayment={(id, payment) => {
                setOrders(orders.map(o => {
                  if (o.id === id) {
                    const newPayments = [...o.payments, payment];
                    const newAmountPaid = newPayments.reduce((sum, p) => sum + p.amount, 0);
                    return { ...o, payments: newPayments, amountPaid: newAmountPaid };
                  }
                  return o;
                }));
              }}
            />
          )}
          
          {activeTab === 'enquiries' && (
            <EnquiryList 
              enquiries={enquiries}
              cardStyle={cardStyle}
              btnPrimary={btnPrimary}
              btnSecondary={btnSecondary}
              onEdit={(enquiry) => { setEditingEnquiry(enquiry); setShowEnquiryForm(true); }}
              onDelete={(id) => setEnquiries(enquiries.filter(e => e.id !== id))}
              onConvert={convertEnquiryToOrder}
            />
          )}
          
          {activeTab === 'settings' && (
            <SettingsPanel 
              settings={settings}
              orders={orders}
              enquiries={enquiries}
              cardStyle={cardStyle}
              btnPrimary={btnPrimary}
              btnSecondary={btnSecondary}
              onSave={setSettings}
              onRestoreData={(data) => {
                if (data.orders) setOrders(data.orders);
                if (data.enquiries) setEnquiries(data.enquiries);
                if (data.settings) setSettings(data.settings);
              }}
            />
          )}
        </main>
      </div>

      {/* Bottom Navigation */}
      <nav style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: '#111',
        borderTop: '2px solid #FFD700',
        display: 'flex',
        justifyContent: 'space-around',
        padding: '8px 0',
        zIndex: 100,
      }}>
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id as any)}
            style={{
              background: 'none',
              border: 'none',
              color: activeTab === item.id ? '#FFD700' : '#666',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '4px',
              cursor: 'pointer',
              padding: '8px 16px',
            }}
          >
            <span style={{ fontSize: '24px' }}>{item.icon}</span>
            <span style={{ fontSize: '11px', fontWeight: activeTab === item.id ? 'bold' : 'normal' }}>
              {item.label}
            </span>
          </button>
        ))}
      </nav>

      {/* Floating Action Button */}
      <button
        onClick={() => {
          if (activeTab === 'enquiries') {
            setShowEnquiryForm(true);
          } else {
            setShowOrderForm(true);
          }
        }}
        style={{
          position: 'fixed',
          bottom: '90px',
          right: '20px',
          width: '60px',
          height: '60px',
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #FFD700, #FFA500)',
          color: '#000',
          border: 'none',
          fontSize: '32px',
          fontWeight: 'bold',
          cursor: 'pointer',
          boxShadow: '0 4px 20px rgba(255, 215, 0, 0.4)',
          zIndex: 100,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        +
      </button>

      {/* Order Form Modal */}
      {showOrderForm && (
        <OrderForm 
          order={editingOrder}
          settings={settings}
          onSave={handleSaveOrder}
          onClose={() => { setShowOrderForm(false); setEditingOrder(null); }}
        />
      )}

      {/* Enquiry Form Modal */}
      {showEnquiryForm && (
        <EnquiryForm 
          enquiry={editingEnquiry}
          onSave={handleSaveEnquiry}
          onClose={() => { setShowEnquiryForm(false); setEditingEnquiry(null); }}
        />
      )}
    </div>
  );
};

// Dashboard Component
const Dashboard: React.FC<{
  orders: Order[];
  enquiries: Enquiry[];
  cardStyle: React.CSSProperties;
  onViewOrders: () => void;
  onViewEnquiries: () => void;
}> = ({ orders, enquiries, cardStyle, onViewOrders, onViewEnquiries }) => {
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
  
  const todayEvents = orders.filter(o => o.eventDate === today);
  const tomorrowEvents = orders.filter(o => o.eventDate === tomorrow);
  const pendingOrders = orders.filter(o => o.status !== 'delivered' && o.status !== 'completed');
  const newEnquiries = enquiries.filter(e => e.status === 'new');
  const totalReceived = orders.reduce((sum, o) => sum + o.amountPaid, 0);
  const totalPending = orders.reduce((sum, o) => sum + (o.totalAmount - o.amountPaid), 0);

  const statCards = [
    { label: 'Pending Orders', value: pendingOrders.length, icon: '📦', color: '#3B82F6', onClick: onViewOrders },
    { label: 'New Enquiries', value: newEnquiries.length, icon: '📋', color: '#F59E0B', onClick: onViewEnquiries },
    { label: 'Amount Received', value: formatCurrency(totalReceived), icon: '💰', color: '#10B981' },
    { label: 'Pending Amount', value: formatCurrency(totalPending), icon: '⏳', color: '#EF4444' },
  ];

  return (
    <div>
      <h2 style={{ 
        fontSize: '24px', 
        fontWeight: 'bold', 
        marginBottom: '24px',
        color: '#FFD700',
      }}>
        📊 Dashboard
      </h2>

      {/* Stats Grid */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', 
        gap: '16px',
        marginBottom: '24px',
      }}>
        {statCards.map((stat, i) => (
          <div 
            key={i} 
            onClick={stat.onClick}
            style={{
              ...cardStyle,
              borderLeft: `4px solid ${stat.color}`,
              cursor: stat.onClick ? 'pointer' : 'default',
            }}
          >
            <div style={{ fontSize: '28px', marginBottom: '8px' }}>{stat.icon}</div>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: stat.color }}>
              {stat.value}
            </div>
            <div style={{ fontSize: '13px', color: '#888' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Today's Events */}
      <div style={{ ...cardStyle, marginBottom: '16px' }}>
        <h3 style={{ 
          fontSize: '16px', 
          fontWeight: 'bold', 
          marginBottom: '16px',
          color: '#FFD700',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
        }}>
          🎯 Today's Events ({todayEvents.length})
        </h3>
        {todayEvents.length === 0 ? (
          <p style={{ color: '#666', textAlign: 'center', padding: '20px' }}>No events today</p>
        ) : (
          todayEvents.map(order => (
            <div key={order.id} style={{
              background: '#222',
              padding: '12px',
              borderRadius: '8px',
              marginBottom: '8px',
              borderLeft: '3px solid #FFD700',
            }}>
              <div style={{ fontWeight: 'bold' }}>{order.customerName}</div>
              <div style={{ fontSize: '13px', color: '#888' }}>
                {order.serviceType.toUpperCase()} • {order.sareeCount} sarees • {order.location === 'onsite' ? '📍 On-Site' : '🏪 At Shop'}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Tomorrow's Events */}
      <div style={{ ...cardStyle, marginBottom: '16px' }}>
        <h3 style={{ 
          fontSize: '16px', 
          fontWeight: 'bold', 
          marginBottom: '16px',
          color: '#FFD700',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
        }}>
          📅 Tomorrow's Events ({tomorrowEvents.length})
        </h3>
        {tomorrowEvents.length === 0 ? (
          <p style={{ color: '#666', textAlign: 'center', padding: '20px' }}>No events tomorrow</p>
        ) : (
          tomorrowEvents.map(order => (
            <div key={order.id} style={{
              background: '#222',
              padding: '12px',
              borderRadius: '8px',
              marginBottom: '8px',
              borderLeft: '3px solid #3B82F6',
            }}>
              <div style={{ fontWeight: 'bold' }}>{order.customerName}</div>
              <div style={{ fontSize: '13px', color: '#888' }}>
                {order.serviceType.toUpperCase()} • {order.sareeCount} sarees • {order.location === 'onsite' ? '📍 On-Site' : '🏪 At Shop'}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Pending Payments */}
      <div style={cardStyle}>
        <h3 style={{ 
          fontSize: '16px', 
          fontWeight: 'bold', 
          marginBottom: '16px',
          color: '#FFD700',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
        }}>
          💳 Pending Payments
        </h3>
        {orders.filter(o => o.totalAmount > o.amountPaid).slice(0, 5).map(order => (
          <div key={order.id} style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            background: '#222',
            padding: '12px',
            borderRadius: '8px',
            marginBottom: '8px',
          }}>
            <div>
              <div style={{ fontWeight: 'bold' }}>{order.customerName}</div>
              <div style={{ fontSize: '12px', color: '#888' }}>{order.phone}</div>
            </div>
            <div style={{ 
              color: '#EF4444', 
              fontWeight: 'bold',
              fontSize: '14px',
            }}>
              {formatCurrency(order.totalAmount - order.amountPaid)}
            </div>
          </div>
        ))}
        {orders.filter(o => o.totalAmount > o.amountPaid).length === 0 && (
          <p style={{ color: '#666', textAlign: 'center', padding: '20px' }}>No pending payments! 🎉</p>
        )}
      </div>
    </div>
  );
};

// Order List Component
const OrderList: React.FC<{
  orders: Order[];
  settings: Settings;
  cardStyle: React.CSSProperties;
  btnPrimary: React.CSSProperties;
  onEdit: (order: Order) => void;
  onDelete: (id: string) => void;
  onUpdateStatus: (id: string, status: Order['status']) => void;
  onAddPayment: (id: string, payment: Payment) => void;
}> = ({ orders, settings, cardStyle, btnPrimary, onEdit, onDelete, onUpdateStatus, onAddPayment }) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('all');
  const [showPaymentModal, setShowPaymentModal] = useState<string | null>(null);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMode, setPaymentMode] = useState('Cash');

  const filteredOrders = orders.filter(o => filter === 'all' || o.status === filter);

  const statusColors: Record<string, string> = {
    'pending': '#F59E0B',
    'received': '#3B82F6',
    'in-progress': '#8B5CF6',
    'completed': '#10B981',
    'delivered': '#6B7280',
  };

  const sendWhatsAppQuotation = (order: Order) => {
    const message = `🪻 *Eyas Saree Drapist* 🪻
━━━━━━━━━━━━━━━━━━
Vanakkam ${order.customerName}! 🙏

📋 *Order Details:*
• Service: ${order.serviceType === 'pre-pleat' ? 'Pre-Pleat' : order.serviceType === 'drape' ? 'Draping' : 'Pre-Pleat + Draping'}
• Sarees: ${order.sareeCount}
• Location: ${order.location === 'onsite' ? 'On-Site' : 'At Shop'}
• Event Date: ${formatDate(order.eventDate)}

💰 *Amount:*
• Base: ${formatCurrency(order.baseAmount)}
${order.additionalCharges.map(c => `• ${c.name}: ${formatCurrency(c.amount)}`).join('\n')}
• *Total: ${formatCurrency(order.totalAmount)}*
• Paid: ${formatCurrency(order.amountPaid)}
• Balance: ${formatCurrency(order.totalAmount - order.amountPaid)}

📸 Instagram: ${settings.instagram}
━━━━━━━━━━━━━━━━━━
Thank you for choosing us! 🙏`;

    window.open(`https://wa.me/91${order.phone}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleAddPayment = () => {
    if (showPaymentModal && paymentAmount) {
      onAddPayment(showPaymentModal, {
        id: generateId(),
        amount: parseFloat(paymentAmount),
        date: new Date().toISOString(),
        mode: paymentMode,
      });
      setShowPaymentModal(null);
      setPaymentAmount('');
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
        <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#FFD700' }}>📦 Orders</h2>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          style={{
            background: '#222',
            color: '#fff',
            border: '1px solid #444',
            padding: '10px 16px',
            borderRadius: '8px',
            fontSize: '14px',
          }}
        >
          <option value="all">All Orders</option>
          <option value="pending">Pending</option>
          <option value="received">Received</option>
          <option value="in-progress">In Progress</option>
          <option value="completed">Completed</option>
          <option value="delivered">Delivered</option>
        </select>
      </div>

      {filteredOrders.length === 0 ? (
        <div style={{ ...cardStyle, textAlign: 'center', padding: '40px' }}>
          <div style={{ fontSize: '48px', marginBottom: '16px' }}>📦</div>
          <p style={{ color: '#888' }}>No orders found</p>
        </div>
      ) : (
        filteredOrders.map(order => (
          <div key={order.id} style={{ ...cardStyle, marginBottom: '16px' }}>
            <div 
              onClick={() => setExpandedId(expandedId === order.id ? null : order.id)}
              style={{ cursor: 'pointer' }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                <div>
                  <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '4px' }}>{order.customerName}</h3>
                  <p style={{ fontSize: '13px', color: '#888' }}>📱 {order.phone}</p>
                </div>
                <span style={{
                  background: statusColors[order.status],
                  color: '#fff',
                  padding: '4px 12px',
                  borderRadius: '20px',
                  fontSize: '12px',
                  fontWeight: 'bold',
                }}>
                  {order.status.toUpperCase()}
                </span>
              </div>

              <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap', fontSize: '13px', color: '#aaa' }}>
                <span>🪻 {order.serviceType === 'pre-pleat' ? 'Pre-Pleat' : order.serviceType === 'drape' ? 'Drape' : 'Both'}</span>
                <span>👗 {order.sareeCount} sarees</span>
                <span>{order.location === 'onsite' ? '📍 On-Site' : '🏪 Shop'}</span>
                <span>📅 {formatDate(order.eventDate)}</span>
              </div>

              <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                marginTop: '12px',
                paddingTop: '12px',
                borderTop: '1px solid #333',
              }}>
                <div>
                  <span style={{ color: '#888', fontSize: '12px' }}>Total: </span>
                  <span style={{ fontWeight: 'bold', color: '#FFD700' }}>{formatCurrency(order.totalAmount)}</span>
                </div>
                <div>
                  <span style={{ color: '#888', fontSize: '12px' }}>Balance: </span>
                  <span style={{ fontWeight: 'bold', color: order.totalAmount - order.amountPaid > 0 ? '#EF4444' : '#10B981' }}>
                    {formatCurrency(order.totalAmount - order.amountPaid)}
                  </span>
                </div>
              </div>
            </div>

            {expandedId === order.id && (
              <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid #333' }}>
                {/* Details */}
                <div style={{ display: 'grid', gap: '8px', fontSize: '14px', marginBottom: '16px' }}>
                  <div><strong>Address:</strong> {order.address || '-'}</div>
                  <div><strong>Saree Received:</strong> {order.sareeReceivedInAdvance ? `Yes (${formatDate(order.sareeReceivedDate)})` : 'No'}</div>
                  <div><strong>Delivery Date:</strong> {formatDate(order.deliveryDate)}</div>
                  <div><strong>Collection Date:</strong> {formatDate(order.collectionDate)}</div>
                  {order.notes && <div><strong>Notes:</strong> {order.notes}</div>}
                </div>

                {/* Charges breakdown */}
                <div style={{ background: '#222', padding: '12px', borderRadius: '8px', marginBottom: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span>Base Amount</span>
                    <span>{formatCurrency(order.baseAmount)}</span>
                  </div>
                  {order.additionalCharges.map((charge, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                      <span>{charge.name}</span>
                      <span>{formatCurrency(charge.amount)}</span>
                    </div>
                  ))}
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', paddingTop: '8px', borderTop: '1px solid #444' }}>
                    <span>Total</span>
                    <span style={{ color: '#FFD700' }}>{formatCurrency(order.totalAmount)}</span>
                  </div>
                </div>

                {/* Payments */}
                <div style={{ marginBottom: '16px' }}>
                  <h4 style={{ fontSize: '14px', fontWeight: 'bold', marginBottom: '8px', color: '#FFD700' }}>Payment History</h4>
                  {order.payments.length === 0 ? (
                    <p style={{ color: '#666', fontSize: '13px' }}>No payments yet</p>
                  ) : (
                    order.payments.map(payment => (
                      <div key={payment.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', padding: '8px', background: '#222', borderRadius: '6px', marginBottom: '4px' }}>
                        <span>{formatDate(payment.date)} • {payment.mode}</span>
                        <span style={{ color: '#10B981' }}>+{formatCurrency(payment.amount)}</span>
                      </div>
                    ))
                  )}
                </div>

                {/* Status update */}
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ fontSize: '13px', color: '#888', display: 'block', marginBottom: '8px' }}>Update Status:</label>
                  <select
                    value={order.status}
                    onChange={(e) => onUpdateStatus(order.id, e.target.value as Order['status'])}
                    style={{
                      width: '100%',
                      background: '#222',
                      color: '#fff',
                      border: '1px solid #444',
                      padding: '10px',
                      borderRadius: '8px',
                    }}
                  >
                    <option value="pending">Pending</option>
                    <option value="received">Saree Received</option>
                    <option value="in-progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="delivered">Delivered</option>
                  </select>
                </div>

                {/* Actions */}
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                  <button 
                    onClick={() => setShowPaymentModal(order.id)}
                    style={{ ...btnPrimary, flex: 1, minWidth: '120px', padding: '10px' }}
                  >
                    💳 Add Payment
                  </button>
                  <button 
                    onClick={() => sendWhatsAppQuotation(order)}
                    style={{ ...btnPrimary, flex: 1, minWidth: '120px', padding: '10px', background: 'linear-gradient(135deg, #25D366, #128C7E)' }}
                  >
                    📱 WhatsApp
                  </button>
                  <button 
                    onClick={() => onEdit(order)}
                    style={{ background: '#333', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '8px', cursor: 'pointer' }}
                  >
                    ✏️
                  </button>
                  <button 
                    onClick={() => { if (confirm('Delete this order?')) onDelete(order.id); }}
                    style={{ background: '#7f1d1d', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '8px', cursor: 'pointer' }}
                  >
                    🗑️
                  </button>
                </div>
              </div>
            )}
          </div>
        ))
      )}

      {/* Payment Modal */}
      {showPaymentModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 200,
          padding: '20px',
        }}>
          <div style={{ ...cardStyle, width: '100%', maxWidth: '400px' }}>
            <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '20px', color: '#FFD700' }}>Add Payment</h3>
            <div style={{ marginBottom: '16px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', color: '#888' }}>Amount</label>
              <input
                type="number"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                placeholder="Enter amount"
                style={{
                  width: '100%',
                  background: '#222',
                  border: '1px solid #444',
                  padding: '12px',
                  borderRadius: '8px',
                  color: '#fff',
                  fontSize: '16px',
                }}
              />
            </div>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', color: '#888' }}>Payment Mode</label>
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value)}
                style={{
                  width: '100%',
                  background: '#222',
                  border: '1px solid #444',
                  padding: '12px',
                  borderRadius: '8px',
                  color: '#fff',
                  fontSize: '16px',
                }}
              >
                <option>Cash</option>
                <option>UPI</option>
                <option>Card</option>
                <option>Bank Transfer</option>
              </select>
            </div>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button onClick={() => setShowPaymentModal(null)} style={{ flex: 1, padding: '12px', background: '#333', color: '#fff', border: 'none', borderRadius: '8px', cursor: 'pointer' }}>
                Cancel
              </button>
              <button onClick={handleAddPayment} style={{ ...btnPrimary, flex: 1 }}>
                Add Payment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Enquiry List Component
const EnquiryList: React.FC<{
  enquiries: Enquiry[];
  cardStyle: React.CSSProperties;
  btnPrimary: React.CSSProperties;
  btnSecondary: React.CSSProperties;
  onEdit: (enquiry: Enquiry) => void;
  onDelete: (id: string) => void;
  onConvert: (enquiry: Enquiry) => void;
}> = ({ enquiries, cardStyle, btnPrimary, btnSecondary: _, onEdit, onDelete, onConvert }) => {
  const [filter, setFilter] = useState<string>('all');

  const filteredEnquiries = enquiries.filter(e => filter === 'all' || e.status === filter);

  const statusColors: Record<string, string> = {
    'new': '#10B981',
    'follow-up': '#F59E0B',
    'converted': '#3B82F6',
    'cancelled': '#6B7280',
  };

  const sendWhatsAppFollowUp = (enquiry: Enquiry) => {
    const message = `🪻 *Eyas Saree Drapist* 🪻

Vanakkam ${enquiry.customerName}! 🙏

Thank you for your enquiry about our ${enquiry.serviceType === 'pre-pleat' ? 'Pre-Pleat' : enquiry.serviceType === 'drape' ? 'Draping' : 'Pre-Pleat & Draping'} service.

📅 Event Date: ${formatDate(enquiry.eventDate)}
👗 Sarees: ${enquiry.sareeCount}

We would love to serve you! Please let us know if you would like to proceed.

📸 Instagram: @eyas_sareedrapist_namakkal

Thank you! 🙏`;

    window.open(`https://wa.me/91${enquiry.phone}?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
        <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#FFD700' }}>📋 Enquiries</h2>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          style={{
            background: '#222',
            color: '#fff',
            border: '1px solid #444',
            padding: '10px 16px',
            borderRadius: '8px',
            fontSize: '14px',
          }}
        >
          <option value="all">All Enquiries</option>
          <option value="new">New</option>
          <option value="follow-up">Follow-up</option>
          <option value="converted">Converted</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      {filteredEnquiries.length === 0 ? (
        <div style={{ ...cardStyle, textAlign: 'center', padding: '40px' }}>
          <div style={{ fontSize: '48px', marginBottom: '16px' }}>📋</div>
          <p style={{ color: '#888' }}>No enquiries found</p>
        </div>
      ) : (
        filteredEnquiries.map(enquiry => (
          <div key={enquiry.id} style={{ ...cardStyle, marginBottom: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <div>
                <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '4px' }}>{enquiry.customerName}</h3>
                <p style={{ fontSize: '13px', color: '#888' }}>📱 {enquiry.phone}</p>
              </div>
              <span style={{
                background: statusColors[enquiry.status],
                color: '#fff',
                padding: '4px 12px',
                borderRadius: '20px',
                fontSize: '12px',
                fontWeight: 'bold',
              }}>
                {enquiry.status.toUpperCase()}
              </span>
            </div>

            <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap', fontSize: '13px', color: '#aaa', marginBottom: '12px' }}>
              <span>🪻 {enquiry.serviceType === 'pre-pleat' ? 'Pre-Pleat' : enquiry.serviceType === 'drape' ? 'Drape' : 'Both'}</span>
              <span>👗 {enquiry.sareeCount} sarees</span>
              <span>{enquiry.location === 'onsite' ? '📍 On-Site' : '🏪 Shop'}</span>
              <span>📅 {formatDate(enquiry.eventDate)}</span>
            </div>

            {enquiry.notes && (
              <p style={{ fontSize: '13px', color: '#888', marginBottom: '12px' }}>
                📝 {enquiry.notes}
              </p>
            )}

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {enquiry.status !== 'converted' && enquiry.status !== 'cancelled' && (
                <button 
                  onClick={() => onConvert(enquiry)}
                  style={{ ...btnPrimary, flex: 1, minWidth: '120px', padding: '10px' }}
                >
                  ✅ Convert to Order
                </button>
              )}
              <button 
                onClick={() => sendWhatsAppFollowUp(enquiry)}
                style={{ ...btnPrimary, flex: 1, minWidth: '120px', padding: '10px', background: 'linear-gradient(135deg, #25D366, #128C7E)' }}
              >
                📱 Follow-up
              </button>
              <button 
                onClick={() => onEdit(enquiry)}
                style={{ background: '#333', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '8px', cursor: 'pointer' }}
              >
                ✏️
              </button>
              <button 
                onClick={() => { if (confirm('Delete this enquiry?')) onDelete(enquiry.id); }}
                style={{ background: '#7f1d1d', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '8px', cursor: 'pointer' }}
              >
                🗑️
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

// Order Form Component
const OrderForm: React.FC<{
  order: Order | null;
  settings: Settings;
  onSave: (order: Order) => void;
  onClose: () => void;
}> = ({ order, settings, onSave, onClose }) => {
  const [formData, setFormData] = useState<Partial<Order>>(() => order || {
    customerName: '',
    phone: '',
    address: '',
    serviceType: 'pre-pleat',
    location: 'shop',
    sareeCount: 1,
    sareeReceivedInAdvance: false,
    sareeReceivedDate: '',
    eventDate: '',
    deliveryDate: '',
    collectionDate: '',
    baseAmount: settings.prePleatRate,
    additionalCharges: [],
    totalAmount: settings.prePleatRate,
    payments: [],
    amountPaid: 0,
    status: 'pending',
    notes: '',
  });

  const [newChargeName, setNewChargeName] = useState('');
  const [newChargeAmount, setNewChargeAmount] = useState('');

  const calculateTotal = () => {
    const base = formData.baseAmount || 0;
    const additional = (formData.additionalCharges || []).reduce((sum, c) => sum + c.amount, 0);
    return base + additional;
  };

  useEffect(() => {
    const rate = formData.serviceType === 'pre-pleat' ? settings.prePleatRate :
                 formData.serviceType === 'drape' ? settings.drapeRate : settings.bothRate;
    const base = rate * (formData.sareeCount || 1);
    setFormData(prev => ({ ...prev, baseAmount: base, totalAmount: base + (prev.additionalCharges || []).reduce((sum, c) => sum + c.amount, 0) }));
  }, [formData.serviceType, formData.sareeCount, settings]);

  const addCharge = () => {
    if (newChargeName && newChargeAmount) {
      const charges = [...(formData.additionalCharges || []), { name: newChargeName, amount: parseFloat(newChargeAmount) }];
      setFormData(prev => ({ ...prev, additionalCharges: charges, totalAmount: (prev.baseAmount || 0) + charges.reduce((sum, c) => sum + c.amount, 0) }));
      setNewChargeName('');
      setNewChargeAmount('');
    }
  };

  const removeCharge = (index: number) => {
    const charges = (formData.additionalCharges || []).filter((_, i) => i !== index);
    setFormData(prev => ({ ...prev, additionalCharges: charges, totalAmount: (prev.baseAmount || 0) + charges.reduce((sum, c) => sum + c.amount, 0) }));
  };

  const handleSubmit = () => {
    if (!formData.customerName || !formData.phone) {
      alert('Please fill in customer name and phone');
      return;
    }
    onSave(formData as Order);
  };

  const inputStyle: React.CSSProperties = {
    width: '100%',
    background: '#222',
    border: '1px solid #444',
    padding: '12px',
    borderRadius: '8px',
    color: '#fff',
    fontSize: '16px',
    marginBottom: '16px',
  };

  const labelStyle: React.CSSProperties = {
    display: 'block',
    marginBottom: '8px',
    fontSize: '14px',
    color: '#FFD700',
    fontWeight: 'bold',
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: '#000',
      zIndex: 200,
      overflow: 'auto',
    }}>
      <div style={{
        padding: '20px',
        paddingBottom: '100px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
          <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#FFD700' }}>
            {order ? '✏️ Edit Order' : '➕ New Order'}
          </h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#fff', fontSize: '28px', cursor: 'pointer' }}>✕</button>
        </div>

        <label style={labelStyle}>Customer Name *</label>
        <input
          type="text"
          value={formData.customerName}
          onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
          placeholder="Enter customer name"
          style={inputStyle}
        />

        <label style={labelStyle}>Phone Number *</label>
        <input
          type="tel"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          placeholder="Enter phone number"
          style={inputStyle}
        />

        <label style={labelStyle}>Address</label>
        <input
          type="text"
          value={formData.address}
          onChange={(e) => setFormData({ ...formData, address: e.target.value })}
          placeholder="Enter address"
          style={inputStyle}
        />

        <label style={labelStyle}>Service Type</label>
        <select
          value={formData.serviceType}
          onChange={(e) => setFormData({ ...formData, serviceType: e.target.value as any })}
          style={inputStyle}
        >
          <option value="pre-pleat">Pre-Pleat Only</option>
          <option value="drape">Draping Only</option>
          <option value="both">Pre-Pleat + Draping</option>
        </select>

        <label style={labelStyle}>Location</label>
        <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
          <button
            onClick={() => setFormData({ ...formData, location: 'shop' })}
            style={{
              flex: 1,
              padding: '12px',
              borderRadius: '8px',
              border: '2px solid',
              borderColor: formData.location === 'shop' ? '#FFD700' : '#444',
              background: formData.location === 'shop' ? 'rgba(255, 215, 0, 0.2)' : 'transparent',
              color: formData.location === 'shop' ? '#FFD700' : '#fff',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            🏪 At Shop
          </button>
          <button
            onClick={() => setFormData({ ...formData, location: 'onsite' })}
            style={{
              flex: 1,
              padding: '12px',
              borderRadius: '8px',
              border: '2px solid',
              borderColor: formData.location === 'onsite' ? '#FFD700' : '#444',
              background: formData.location === 'onsite' ? 'rgba(255, 215, 0, 0.2)' : 'transparent',
              color: formData.location === 'onsite' ? '#FFD700' : '#fff',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            📍 On-Site
          </button>
        </div>

        <label style={labelStyle}>Number of Sarees</label>
        <input
          type="number"
          value={formData.sareeCount}
          onChange={(e) => setFormData({ ...formData, sareeCount: parseInt(e.target.value) || 1 })}
          min="1"
          style={inputStyle}
        />

        <label style={labelStyle}>Saree Received</label>
        <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
          <button
            onClick={() => setFormData({ ...formData, sareeReceivedInAdvance: true })}
            style={{
              flex: 1,
              padding: '12px',
              borderRadius: '8px',
              border: '2px solid',
              borderColor: formData.sareeReceivedInAdvance ? '#10B981' : '#444',
              background: formData.sareeReceivedInAdvance ? 'rgba(16, 185, 129, 0.2)' : 'transparent',
              color: formData.sareeReceivedInAdvance ? '#10B981' : '#fff',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            ✅ In Advance
          </button>
          <button
            onClick={() => setFormData({ ...formData, sareeReceivedInAdvance: false })}
            style={{
              flex: 1,
              padding: '12px',
              borderRadius: '8px',
              border: '2px solid',
              borderColor: !formData.sareeReceivedInAdvance ? '#F59E0B' : '#444',
              background: !formData.sareeReceivedInAdvance ? 'rgba(245, 158, 11, 0.2)' : 'transparent',
              color: !formData.sareeReceivedInAdvance ? '#F59E0B' : '#fff',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            📍 On-Site
          </button>
        </div>

        {formData.sareeReceivedInAdvance && (
          <>
            <label style={labelStyle}>Saree Received Date</label>
            <input
              type="date"
              value={formData.sareeReceivedDate}
              onChange={(e) => setFormData({ ...formData, sareeReceivedDate: e.target.value })}
              style={inputStyle}
            />
          </>
        )}

        <label style={labelStyle}>Event Date</label>
        <input
          type="date"
          value={formData.eventDate}
          onChange={(e) => setFormData({ ...formData, eventDate: e.target.value })}
          style={inputStyle}
        />

        <label style={labelStyle}>Delivery Date</label>
        <input
          type="date"
          value={formData.deliveryDate}
          onChange={(e) => setFormData({ ...formData, deliveryDate: e.target.value })}
          style={inputStyle}
        />

        <label style={labelStyle}>Collection Date</label>
        <input
          type="date"
          value={formData.collectionDate}
          onChange={(e) => setFormData({ ...formData, collectionDate: e.target.value })}
          style={inputStyle}
        />

        {/* Pricing */}
        <div style={{ background: '#1a1a1a', padding: '16px', borderRadius: '12px', marginBottom: '16px', border: '1px solid #333' }}>
          <h3 style={{ color: '#FFD700', marginBottom: '16px', fontSize: '16px', fontWeight: 'bold' }}>💰 Pricing</h3>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
            <span>Base Amount ({formData.sareeCount} × ₹{formData.serviceType === 'pre-pleat' ? settings.prePleatRate : formData.serviceType === 'drape' ? settings.drapeRate : settings.bothRate})</span>
            <span style={{ fontWeight: 'bold' }}>{formatCurrency(formData.baseAmount || 0)}</span>
          </div>

          {(formData.additionalCharges || []).map((charge, index) => (
            <div key={index} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <span>{charge.name}</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span>{formatCurrency(charge.amount)}</span>
                <button onClick={() => removeCharge(index)} style={{ background: 'none', border: 'none', color: '#EF4444', cursor: 'pointer' }}>✕</button>
              </div>
            </div>
          ))}

          {/* Add charge */}
          <div style={{ borderTop: '1px solid #333', paddingTop: '12px', marginTop: '12px' }}>
            <label style={{ fontSize: '13px', color: '#888' }}>Add Extra Charge</label>
            <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
              <select
                value={newChargeName}
                onChange={(e) => setNewChargeName(e.target.value)}
                style={{ flex: 2, background: '#222', border: '1px solid #444', padding: '10px', borderRadius: '6px', color: '#fff' }}
              >
                <option value="">Select charge</option>
                {settings.customChargeHeads.map(head => (
                  <option key={head} value={head}>{head}</option>
                ))}
              </select>
              <input
                type="number"
                value={newChargeAmount}
                onChange={(e) => setNewChargeAmount(e.target.value)}
                placeholder="₹"
                style={{ flex: 1, background: '#222', border: '1px solid #444', padding: '10px', borderRadius: '6px', color: '#fff' }}
              />
              <button onClick={addCharge} style={{ background: '#FFD700', color: '#000', border: 'none', padding: '10px 16px', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer' }}>+</button>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #444', fontWeight: 'bold', fontSize: '18px' }}>
            <span>Total</span>
            <span style={{ color: '#FFD700' }}>{formatCurrency(calculateTotal())}</span>
          </div>
        </div>

        <label style={labelStyle}>Notes</label>
        <textarea
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          placeholder="Add any notes..."
          rows={3}
          style={{ ...inputStyle, resize: 'vertical' }}
        />

        <div style={{ display: 'flex', gap: '12px', marginTop: '24px' }}>
          <button onClick={onClose} style={{ flex: 1, padding: '16px', background: '#333', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '16px', cursor: 'pointer' }}>
            Cancel
          </button>
          <button onClick={handleSubmit} style={{ flex: 2, padding: '16px', background: 'linear-gradient(135deg, #FFD700, #FFA500)', color: '#000', border: 'none', borderRadius: '8px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer' }}>
            {order ? 'Update Order' : 'Create Order'}
          </button>
        </div>
      </div>
    </div>
  );
};

// Enquiry Form Component
const EnquiryForm: React.FC<{
  enquiry: Enquiry | null;
  onSave: (enquiry: Enquiry) => void;
  onClose: () => void;
}> = ({ enquiry, onSave, onClose }) => {
  const [formData, setFormData] = useState<Partial<Enquiry>>(() => enquiry || {
    customerName: '',
    phone: '',
    serviceType: 'pre-pleat',
    location: 'shop',
    eventDate: '',
    sareeCount: 1,
    notes: '',
    status: 'new',
  });

  const handleSubmit = () => {
    if (!formData.customerName || !formData.phone) {
      alert('Please fill in customer name and phone');
      return;
    }
    onSave(formData as Enquiry);
  };

  const inputStyle: React.CSSProperties = {
    width: '100%',
    background: '#222',
    border: '1px solid #444',
    padding: '12px',
    borderRadius: '8px',
    color: '#fff',
    fontSize: '16px',
    marginBottom: '16px',
  };

  const labelStyle: React.CSSProperties = {
    display: 'block',
    marginBottom: '8px',
    fontSize: '14px',
    color: '#FFD700',
    fontWeight: 'bold',
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: '#000',
      zIndex: 200,
      overflow: 'auto',
    }}>
      <div style={{ padding: '20px', paddingBottom: '100px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
          <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#FFD700' }}>
            {enquiry ? '✏️ Edit Enquiry' : '➕ New Enquiry'}
          </h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#fff', fontSize: '28px', cursor: 'pointer' }}>✕</button>
        </div>

        <label style={labelStyle}>Customer Name *</label>
        <input
          type="text"
          value={formData.customerName}
          onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
          placeholder="Enter customer name"
          style={inputStyle}
        />

        <label style={labelStyle}>Phone Number *</label>
        <input
          type="tel"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          placeholder="Enter phone number"
          style={inputStyle}
        />

        <label style={labelStyle}>Service Type</label>
        <select
          value={formData.serviceType}
          onChange={(e) => setFormData({ ...formData, serviceType: e.target.value as any })}
          style={inputStyle}
        >
          <option value="pre-pleat">Pre-Pleat Only</option>
          <option value="drape">Draping Only</option>
          <option value="both">Pre-Pleat + Draping</option>
        </select>

        <label style={labelStyle}>Location</label>
        <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
          <button
            onClick={() => setFormData({ ...formData, location: 'shop' })}
            style={{
              flex: 1,
              padding: '12px',
              borderRadius: '8px',
              border: '2px solid',
              borderColor: formData.location === 'shop' ? '#FFD700' : '#444',
              background: formData.location === 'shop' ? 'rgba(255, 215, 0, 0.2)' : 'transparent',
              color: formData.location === 'shop' ? '#FFD700' : '#fff',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            🏪 At Shop
          </button>
          <button
            onClick={() => setFormData({ ...formData, location: 'onsite' })}
            style={{
              flex: 1,
              padding: '12px',
              borderRadius: '8px',
              border: '2px solid',
              borderColor: formData.location === 'onsite' ? '#FFD700' : '#444',
              background: formData.location === 'onsite' ? 'rgba(255, 215, 0, 0.2)' : 'transparent',
              color: formData.location === 'onsite' ? '#FFD700' : '#fff',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            📍 On-Site
          </button>
        </div>

        <label style={labelStyle}>Number of Sarees</label>
        <input
          type="number"
          value={formData.sareeCount}
          onChange={(e) => setFormData({ ...formData, sareeCount: parseInt(e.target.value) || 1 })}
          min="1"
          style={inputStyle}
        />

        <label style={labelStyle}>Event Date</label>
        <input
          type="date"
          value={formData.eventDate}
          onChange={(e) => setFormData({ ...formData, eventDate: e.target.value })}
          style={inputStyle}
        />

        <label style={labelStyle}>Status</label>
        <select
          value={formData.status}
          onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
          style={inputStyle}
        >
          <option value="new">New</option>
          <option value="follow-up">Follow-up</option>
          <option value="converted">Converted</option>
          <option value="cancelled">Cancelled</option>
        </select>

        <label style={labelStyle}>Notes</label>
        <textarea
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          placeholder="Add any notes..."
          rows={3}
          style={{ ...inputStyle, resize: 'vertical' }}
        />

        <div style={{ display: 'flex', gap: '12px', marginTop: '24px' }}>
          <button onClick={onClose} style={{ flex: 1, padding: '16px', background: '#333', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '16px', cursor: 'pointer' }}>
            Cancel
          </button>
          <button onClick={handleSubmit} style={{ flex: 2, padding: '16px', background: 'linear-gradient(135deg, #FFD700, #FFA500)', color: '#000', border: 'none', borderRadius: '8px', fontSize: '16px', fontWeight: 'bold', cursor: 'pointer' }}>
            {enquiry ? 'Update Enquiry' : 'Create Enquiry'}
          </button>
        </div>
      </div>
    </div>
  );
};

// Settings Panel Component
const SettingsPanel: React.FC<{
  settings: Settings;
  orders: Order[];
  enquiries: Enquiry[];
  cardStyle: React.CSSProperties;
  btnPrimary: React.CSSProperties;
  btnSecondary: React.CSSProperties;
  onSave: (settings: Settings) => void;
  onRestoreData: (data: { orders?: Order[]; enquiries?: Enquiry[]; settings?: Settings }) => void;
}> = ({ settings, orders, enquiries, cardStyle, btnPrimary, onSave, onRestoreData }) => {
  const [formData, setFormData] = useState(settings);
  const [newChargeHead, setNewChargeHead] = useState('');

  const inputStyle: React.CSSProperties = {
    width: '100%',
    background: '#222',
    border: '1px solid #444',
    padding: '12px',
    borderRadius: '8px',
    color: '#fff',
    fontSize: '16px',
    marginBottom: '16px',
  };

  const labelStyle: React.CSSProperties = {
    display: 'block',
    marginBottom: '8px',
    fontSize: '14px',
    color: '#FFD700',
    fontWeight: 'bold',
  };

  const handleSave = () => {
    onSave(formData);
    alert('Settings saved!');
  };

  const addChargeHead = () => {
    if (newChargeHead && !formData.customChargeHeads.includes(newChargeHead)) {
      setFormData({ ...formData, customChargeHeads: [...formData.customChargeHeads, newChargeHead] });
      setNewChargeHead('');
    }
  };

  const removeChargeHead = (head: string) => {
    setFormData({ ...formData, customChargeHeads: formData.customChargeHeads.filter(h => h !== head) });
  };

  const exportData = () => {
    const data = { orders, enquiries, settings, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `eyas_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportCSV = () => {
    const headers = ['Customer', 'Phone', 'Service', 'Location', 'Sarees', 'Event Date', 'Total', 'Paid', 'Balance', 'Status'];
    const rows = orders.map(o => [
      o.customerName, o.phone, o.serviceType, o.location, o.sareeCount,
      o.eventDate, o.totalAmount, o.amountPaid, o.totalAmount - o.amountPaid, o.status
    ]);
    const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `eyas_orders_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target?.result as string);
          if (confirm('This will replace all existing data. Continue?')) {
            onRestoreData(data);
            alert('Data restored successfully!');
          }
        } catch {
          alert('Invalid backup file');
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '24px', color: '#FFD700' }}>⚙️ Settings</h2>

      {/* Business Info */}
      <div style={{ ...cardStyle, marginBottom: '16px' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 'bold', marginBottom: '16px', color: '#FFD700' }}>🏢 Business Info</h3>
        
        <label style={labelStyle}>Business Name</label>
        <input
          type="text"
          value={formData.businessName}
          onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
          style={inputStyle}
        />

        <label style={labelStyle}>Phone</label>
        <input
          type="tel"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          style={inputStyle}
        />

        <label style={labelStyle}>Address</label>
        <input
          type="text"
          value={formData.address}
          onChange={(e) => setFormData({ ...formData, address: e.target.value })}
          style={inputStyle}
        />

        <label style={labelStyle}>Instagram Handle</label>
        <input
          type="text"
          value={formData.instagram}
          onChange={(e) => setFormData({ ...formData, instagram: e.target.value })}
          style={inputStyle}
        />
      </div>

      {/* Pricing */}
      <div style={{ ...cardStyle, marginBottom: '16px' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 'bold', marginBottom: '16px', color: '#FFD700' }}>💰 Default Pricing (Per Saree)</h3>
        
        <label style={labelStyle}>Pre-Pleat Rate</label>
        <input
          type="number"
          value={formData.prePleatRate}
          onChange={(e) => setFormData({ ...formData, prePleatRate: parseInt(e.target.value) || 0 })}
          style={inputStyle}
        />

        <label style={labelStyle}>Draping Rate</label>
        <input
          type="number"
          value={formData.drapeRate}
          onChange={(e) => setFormData({ ...formData, drapeRate: parseInt(e.target.value) || 0 })}
          style={inputStyle}
        />

        <label style={labelStyle}>Pre-Pleat + Draping Rate</label>
        <input
          type="number"
          value={formData.bothRate}
          onChange={(e) => setFormData({ ...formData, bothRate: parseInt(e.target.value) || 0 })}
          style={inputStyle}
        />
      </div>

      {/* Charge Heads */}
      <div style={{ ...cardStyle, marginBottom: '16px' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 'bold', marginBottom: '16px', color: '#FFD700' }}>📋 Additional Charge Heads</h3>
        
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '16px' }}>
          {formData.customChargeHeads.map(head => (
            <span key={head} style={{
              background: '#333',
              padding: '8px 12px',
              borderRadius: '20px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '14px',
            }}>
              {head}
              <button onClick={() => removeChargeHead(head)} style={{ background: 'none', border: 'none', color: '#EF4444', cursor: 'pointer' }}>✕</button>
            </span>
          ))}
        </div>

        <div style={{ display: 'flex', gap: '8px' }}>
          <input
            type="text"
            value={newChargeHead}
            onChange={(e) => setNewChargeHead(e.target.value)}
            placeholder="New charge head"
            style={{ ...inputStyle, marginBottom: 0, flex: 1 }}
          />
          <button onClick={addChargeHead} style={{ ...btnPrimary, padding: '12px 20px' }}>Add</button>
        </div>
      </div>

      {/* Data Management */}
      <div style={{ ...cardStyle, marginBottom: '16px' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 'bold', marginBottom: '16px', color: '#FFD700' }}>💾 Data Management</h3>
        
        <div style={{ display: 'grid', gap: '12px' }}>
          <button onClick={exportData} style={{ ...btnPrimary, width: '100%' }}>
            📥 Download Backup (JSON)
          </button>
          <button onClick={exportCSV} style={{ ...btnPrimary, width: '100%' }}>
            📊 Export Orders (CSV)
          </button>
          <label style={{ width: '100%', cursor: 'pointer', textAlign: 'center', padding: '12px 24px', borderRadius: '8px', border: '2px solid #FFD700', color: '#FFD700', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
            📤 Restore Backup
            <input type="file" accept=".json" onChange={importData} style={{ display: 'none' }} />
          </label>
        </div>
      </div>

      <button onClick={handleSave} style={{ ...btnPrimary, width: '100%', padding: '16px', fontSize: '18px' }}>
        💾 Save Settings
      </button>
    </div>
  );
};

export default App;
