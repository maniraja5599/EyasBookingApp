import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { Order, Enquiry, AppData } from '../types';
import { format } from 'date-fns';

export const exportToPDF = (orders: Order[], title: string = 'Orders Report') => {
  const doc = new jsPDF();
  
  doc.setFontSize(18);
  doc.text(title, 14, 22);
  doc.setFontSize(11);
  doc.text(`Generated: ${format(new Date(), 'dd/MM/yyyy HH:mm')}`, 14, 30);
  
  const tableData = orders.map(order => [
    order.orderNumber,
    order.customerName,
    order.phone,
    order.serviceType.replace('-', ' ').toUpperCase(),
    order.serviceLocation === 'on-site' ? 'On-Site' : 'At Shop',
    format(new Date(order.eventDate), 'dd/MM/yyyy'),
    `₹${order.totalAmount}`,
    `₹${order.amountPaid}`,
    order.status.toUpperCase()
  ]);

  autoTable(doc, {
    head: [['Order #', 'Customer', 'Phone', 'Service', 'Location', 'Event Date', 'Total', 'Paid', 'Status']],
    body: tableData,
    startY: 35,
    styles: { fontSize: 8 },
    headStyles: { fillColor: [99, 102, 241] }
  });

  doc.save(`${title.replace(/\s+/g, '_')}_${format(new Date(), 'yyyyMMdd')}.pdf`);
};

export const exportToExcel = (orders: Order[], filename: string = 'orders') => {
  const data = orders.map(order => ({
    'Order Number': order.orderNumber,
    'Customer Name': order.customerName,
    'Phone': order.phone,
    'Address': order.address,
    'Service Type': order.serviceType.replace('-', ' ').toUpperCase(),
    'Location': order.serviceLocation === 'on-site' ? 'On-Site' : 'At Shop',
    'Saree Count': order.sareeCount,
    'Saree Received': order.sareeReceivedInAdvance ? 'In Advance' : 'On-Site',
    'Event Date': order.eventDate ? format(new Date(order.eventDate), 'dd/MM/yyyy') : '',
    'Delivery Date': order.deliveryDate ? format(new Date(order.deliveryDate), 'dd/MM/yyyy') : '',
    'Base Amount': order.baseAmount,
    'Additional Charges': order.additionalCharges.reduce((sum, c) => sum + c.amount, 0),
    'Total Amount': order.totalAmount,
    'Amount Paid': order.amountPaid,
    'Balance': order.totalAmount - order.amountPaid,
    'Payment Status': order.paymentStatus.toUpperCase(),
    'Order Status': order.status.toUpperCase(),
    'Notes': order.notes,
    'Created': format(new Date(order.createdAt), 'dd/MM/yyyy HH:mm')
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Orders');
  XLSX.writeFile(wb, `${filename}_${format(new Date(), 'yyyyMMdd')}.xlsx`);
};

export const exportToCSV = (orders: Order[], filename: string = 'orders') => {
  const data = orders.map(order => ({
    'Order Number': order.orderNumber,
    'Customer Name': order.customerName,
    'Phone': order.phone,
    'Address': order.address,
    'Service Type': order.serviceType,
    'Location': order.serviceLocation,
    'Saree Count': order.sareeCount,
    'Event Date': order.eventDate,
    'Delivery Date': order.deliveryDate,
    'Total Amount': order.totalAmount,
    'Amount Paid': order.amountPaid,
    'Payment Status': order.paymentStatus,
    'Order Status': order.status,
    'Notes': order.notes
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  const csv = XLSX.utils.sheet_to_csv(ws);
  
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${filename}_${format(new Date(), 'yyyyMMdd')}.csv`;
  link.click();
};

export const exportEnquiriesToExcel = (enquiries: Enquiry[]) => {
  const data = enquiries.map(enq => ({
    'Customer Name': enq.customerName,
    'Phone': enq.phone,
    'Service Type': enq.serviceType.replace('-', ' ').toUpperCase(),
    'Location': enq.serviceLocation === 'on-site' ? 'On-Site' : 'At Shop',
    'Event Date': enq.eventDate ? format(new Date(enq.eventDate), 'dd/MM/yyyy') : '',
    'Status': enq.status.toUpperCase(),
    'Notes': enq.notes,
    'Created': format(new Date(enq.createdAt), 'dd/MM/yyyy HH:mm')
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Enquiries');
  XLSX.writeFile(wb, `enquiries_${format(new Date(), 'yyyyMMdd')}.xlsx`);
};

export const backupData = (data: AppData) => {
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `eyas_drapist_backup_${format(new Date(), 'yyyyMMdd_HHmmss')}.json`;
  link.click();
};

export const generateGoogleSheetsCSV = (orders: Order[]) => {
  const data = orders.map(order => [
    order.orderNumber,
    order.customerName,
    order.phone,
    order.address,
    order.serviceType,
    order.serviceLocation,
    order.sareeCount,
    order.sareeReceivedInAdvance ? 'Yes' : 'No',
    order.eventDate,
    order.deliveryDate,
    order.baseAmount,
    order.additionalCharges.map(c => `${c.headName}:${c.amount}`).join('; '),
    order.totalAmount,
    order.amountPaid,
    order.totalAmount - order.amountPaid,
    order.paymentStatus,
    order.status,
    order.notes,
    order.createdAt
  ]);

  const headers = [
    'Order Number', 'Customer Name', 'Phone', 'Address', 'Service Type', 
    'Location', 'Saree Count', 'Saree In Advance', 'Event Date', 'Delivery Date',
    'Base Amount', 'Additional Charges', 'Total Amount', 'Paid', 'Balance',
    'Payment Status', 'Status', 'Notes', 'Created'
  ];

  const ws = XLSX.utils.aoa_to_sheet([headers, ...data]);
  const csv = XLSX.utils.sheet_to_csv(ws);
  
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `google_sheets_import_${format(new Date(), 'yyyyMMdd')}.csv`;
  link.click();
};
