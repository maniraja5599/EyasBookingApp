import { Order, Enquiry } from '../types';
import { format } from 'date-fns';

export const generateQuotationMessage = (order: Order, businessName: string, businessPhone: string): string => {
  const serviceTypeText = {
    'pre-pleat': 'Pre-Pleat',
    'drape': 'Drape Only',
    'pre-pleat-drape': 'Pre-Pleat + Drape'
  }[order.serviceType];

  const locationText = order.serviceLocation === 'on-site' ? 'On-Site Service' : 'At Shop';

  let message = `🪷 *${businessName}* 🪷\n`;
  message += `━━━━━━━━━━━━━━━\n`;
  message += `📋 *QUOTATION*\n`;
  message += `━━━━━━━━━━━━━━━\n\n`;
  
  message += `*Order #:* ${order.orderNumber}\n`;
  message += `*Customer:* ${order.customerName}\n\n`;
  
  message += `👗 *Service Details:*\n`;
  message += `├ Type: ${serviceTypeText}\n`;
  message += `├ Location: ${locationText}\n`;
  message += `├ Sarees: ${order.sareeCount}\n`;
  message += `└ Event: ${format(new Date(order.eventDate), 'dd MMM yyyy')}\n\n`;
  
  message += `💰 *Pricing:*\n`;
  message += `├ Base Amount: ₹${order.baseAmount}\n`;
  
  if (order.additionalCharges.length > 0) {
    order.additionalCharges.forEach((charge) => {
      message += `├ ${charge.headName}: ₹${charge.amount}\n`;
    });
  }
  
  message += `└ *Total: ₹${order.totalAmount}*\n\n`;
  
  if (order.amountPaid > 0) {
    message += `💳 *Payment:*\n`;
    message += `├ Paid: ₹${order.amountPaid}\n`;
    message += `└ Balance: ₹${order.totalAmount - order.amountPaid}\n\n`;
  }
  
  message += `━━━━━━━━━━━━━━━\n`;
  if (businessPhone) {
    message += `📞 Contact: ${businessPhone}\n`;
  }
  message += `📸 Instagram: @eyas_sareedrapist_namakkal\n`;
  message += `━━━━━━━━━━━━━━━\n`;
  message += `Thank you for choosing us! 🙏✨`;
  
  return message;
};

export const sendWhatsAppQuotation = (phone: string, message: string) => {
  // Clean phone number (remove spaces, dashes, etc.)
  let cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
  
  // Add country code if not present
  if (!cleanPhone.startsWith('+')) {
    if (cleanPhone.startsWith('0')) {
      cleanPhone = '+91' + cleanPhone.substring(1);
    } else {
      cleanPhone = '+91' + cleanPhone;
    }
  }
  
  const encodedMessage = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/${cleanPhone.replace('+', '')}?text=${encodedMessage}`;
  
  window.open(whatsappUrl, '_blank');
};

export const generateEnquiryFollowUpMessage = (enquiry: Enquiry, businessName: string): string => {
  const serviceTypeText = {
    'pre-pleat': 'Pre-Pleat',
    'drape': 'Drape Only',
    'pre-pleat-drape': 'Pre-Pleat + Drape'
  }[enquiry.serviceType];

  let message = `Vanakkam ${enquiry.customerName}! 🙏\n\n`;
  message += `This is a follow-up from *${businessName}* regarding your enquiry for *${serviceTypeText}* service.\n\n`;
  
  if (enquiry.eventDate) {
    message += `📅 Event Date: ${format(new Date(enquiry.eventDate), 'dd MMM yyyy')}\n\n`;
  }
  
  message += `Would you like to proceed with the booking? We offer:\n`;
  message += `✨ Professional Saree Draping\n`;
  message += `✨ Perfect Pre-Pleating\n`;
  message += `✨ On-Site & Shop Services\n\n`;
  message += `Please let us know if you have any questions!\n\n`;
  message += `📸 Follow us: @eyas_sareedrapist_namakkal\n`;
  message += `Thank you! 😊🪷`;
  
  return message;
};
