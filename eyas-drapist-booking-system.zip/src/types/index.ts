export type ServiceType = 'pre-pleat' | 'drape' | 'pre-pleat-drape';
export type ServiceLocation = 'at-shop' | 'on-site';
export type SareeStatus = 'pending' | 'received' | 'in-progress' | 'completed' | 'delivered';
export type PaymentStatus = 'pending' | 'partial' | 'paid';
export type EnquiryStatus = 'new' | 'follow-up' | 'converted' | 'cancelled';

export interface ChargeHead {
  id: string;
  name: string;
  defaultAmount: number;
  isSystem: boolean;
}

export interface Charge {
  headId: string;
  headName: string;
  amount: number;
}

export interface Enquiry {
  id: string;
  customerName: string;
  phone: string;
  serviceType: ServiceType;
  serviceLocation: ServiceLocation;
  eventDate: string;
  notes: string;
  status: EnquiryStatus;
  createdAt: string;
  updatedAt: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerName: string;
  phone: string;
  address: string;
  serviceType: ServiceType;
  serviceLocation: ServiceLocation;
  
  // Saree details
  sareeCount: number;
  sareeReceivedDate: string | null;
  sareeReceivedInAdvance: boolean;
  
  // Dates
  eventDate: string;
  deliveryDate: string;
  collectedDate: string | null;
  
  // Pricing
  baseAmount: number;
  additionalCharges: Charge[];
  totalAmount: number;
  amountPaid: number;
  paymentStatus: PaymentStatus;
  
  // Status
  status: SareeStatus;
  notes: string;
  
  // Metadata
  enquiryId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface AppSettings {
  businessName: string;
  phone: string;
  address: string;
  instagram: string;
  prePleatRate: number;
  drapeRate: number;
  prePleatDrapeRate: number;
}

export interface AppData {
  enquiries: Enquiry[];
  orders: Order[];
  chargeHeads: ChargeHead[];
  settings: AppSettings;
}
